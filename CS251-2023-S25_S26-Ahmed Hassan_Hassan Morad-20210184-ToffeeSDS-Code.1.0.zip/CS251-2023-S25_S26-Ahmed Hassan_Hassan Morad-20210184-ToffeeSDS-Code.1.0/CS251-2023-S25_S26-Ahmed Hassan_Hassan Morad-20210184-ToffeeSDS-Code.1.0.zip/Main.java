import com.System.AppSystem;

public class Main {
    public static void main(String[] args) {
        AppSystem system = new AppSystem();
    }
}
