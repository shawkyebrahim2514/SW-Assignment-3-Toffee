package com.ShippingCart;

/**
 * Status Type of the order
 */
public enum StatusType {
    ORDERED, SHIPPED, DELIVERED, CANCELLED
}