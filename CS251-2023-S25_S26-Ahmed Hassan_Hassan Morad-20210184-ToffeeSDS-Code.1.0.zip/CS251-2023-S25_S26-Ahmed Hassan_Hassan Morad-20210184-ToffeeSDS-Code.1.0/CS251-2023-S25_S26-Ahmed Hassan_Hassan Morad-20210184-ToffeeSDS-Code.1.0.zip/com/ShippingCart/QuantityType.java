package com.ShippingCart;

/**
 * Quantity Type of the item
 */
public enum QuantityType {
    PACKAGE, KILOS
}
