package com.User;

public class Admin extends User {

}
